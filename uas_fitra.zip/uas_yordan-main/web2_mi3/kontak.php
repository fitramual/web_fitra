<h1>Kontak</h1>
<form action="" method="POST">
    <label for="">Nama</label>
    <input type="text" name="nama">
    <label for="">Email</label>
    <input type="text" name="tl">
    <label for="">Pesan</label>
    <input type="text" name="tl">
    <button type="submit" name="cetak">Kirim</button>
</form>